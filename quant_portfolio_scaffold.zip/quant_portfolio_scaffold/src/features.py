#!/usr/bin/env python3
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = ROOT / "outputs"

def pct_change_log(s, n):
    return np.log(s/s.shift(n))

def realized_vol(returns, window=21):
    return returns.rolling(window).std() * np.sqrt(252)

def build_features(cfg_path: Path):
    cfg = json.loads(Path(cfg_path).read_text())
    prices = pd.read_parquet(ROOT/"outputs"/"prices.parquet")

    # prices: multi-column with (ticker, [Adj Close, Volume])
    # We'll work on Adj Close
    px = prices.xs("Adj Close", level=1, axis=1)
    vol = prices.xs("Volume", level=1, axis=1)

    rets = np.log(px/px.shift(1))
    feats = {}
    # Per-asset features
    for t in px.columns:
        df = pd.DataFrame(index=px.index)
        df["ret_1"] = rets[t]
        for n in [5,21,63,126]:
            df[f"ret_{n}"] = pct_change_log(px[t], n)
        for w in [21,63]:
            df[f"rv_{w}"] = realized_vol(rets[t], w)
        df["mom_252_21"] = pct_change_log(px[t],252) - pct_change_log(px[t],21)  # 12-1
        df["vol_z"] = (vol[t] - vol[t].rolling(63).mean())/ (vol[t].rolling(63).std() + 1e-9)
        feats[t] = df

    # Cross-asset correlations to SPY/QQQ/TLT (optional)
    base = {"SPY","QQQ","TLT"} & set(px.columns)
    for b in base:
        corr = rets.rolling(63).corr(rets[b]).rename(columns=lambda c: f"corr63_{b}_{c}")
        # corr is wide-by-ticker; append per column
        for t in px.columns:
            if t in corr.columns:
                feats[t][f"corr63_{b}"] = corr[f"corr63_{b}_{t}"]

    # Combine to panel
    panel = pd.concat({k:v for k,v in feats.items()}, axis=1)

    # Expanding z-score normalization per feature per asset
    def expanding_z(x):
        mu = x.expanding().mean()
        sd = x.expanding().std().replace(0, np.nan)
        return (x - mu)/sd
    panel_norm = panel.groupby(level=0, axis=1).transform(expanding_z)

    out_path = cfg["panel_path"]
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    panel_norm.to_parquet(out_path)
    print(f"[ok] wrote normalized feature panel -> {out_path}, shape={panel_norm.shape}")
    return out_path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", type=str, default=str(ROOT/"config.json"))
    args = ap.parse_args()
    build_features(Path(args.config))

if __name__ == "__main__":
    main()
